# Struct `Editions`

```cadence
pub struct Editions {

    pub let infoList: [Edition]
}
```

Wrapper view for multiple Edition views

### Initializer

```cadence
init(_: [Edition])
```


