# Struct `Medias`

```cadence
pub struct Medias {

    pub let items: [Media]
}
```

Wrapper view for multiple media views

### Initializer

```cadence
init(_: [Media])
```


