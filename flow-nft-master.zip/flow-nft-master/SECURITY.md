
# Responsible Disclosure Policy

Flow was built from the ground up with security in mind. Our code, infrastructure, and development methodology helps us keep our users safe.

We really appreciate the community's help. Responsible disclosure of vulnerabilities helps to maintain the security and privacy of everyone.

If you care about making a difference, please follow the guidelines below.

# **Guidelines For Responsible Disclosure**

We ask that all researchers adhere to these guidelines [here](https://flow.com/flow-responsible-disclosure)
